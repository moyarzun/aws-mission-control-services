import { EC2Client, StartInstancesCommand, StopInstancesCommand } from "@aws-sdk/client-ec2";

const client = new EC2Client({ region: "us-east-2" });
const INSTANCE_ID = 'i-0ea34d801198e033e';

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));
  const action = event.action ? event.action.toLowerCase() : null;

  try {
    let command;
    if (action === 'start') {
      console.log(`Attempting to start instance ${INSTANCE_ID}`);
      command = new StartInstancesCommand({ InstanceIds: [INSTANCE_ID] });
    } else if (action === 'stop') {
      console.log(`Attempting to stop instance ${INSTANCE_ID}`);
      command = new StopInstancesCommand({ InstanceIds: [INSTANCE_ID] });
    } else {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "Invalid action. Provide 'action': 'start' or 'stop'." })
      };
    }

    const response = await client.send(command);
    console.log("Command executed successfully:", response);
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: `Instance ${action} command sent successfully.`,
        details: response
      })
    };
  } catch (err) {
    console.error("Error executing command:", err);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Error executing command", error: err.message })
    };
  }
};
